export enum CareerContactFormStatusEnum {
  NEW = 'NEW',
  IN_REVIEW = 'IN REVIEW',
  REJECT = 'REJECT',
  ACCEPTED = 'ACCEPTED',
}
