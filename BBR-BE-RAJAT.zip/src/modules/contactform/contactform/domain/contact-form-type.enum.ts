export enum ContactFormType {
  ERROR = 'ERROR',
  SUGGEST_FEATURE = 'SUGGEST_FEATURE',
}
