export enum ClaimProfileContactFormStatus {
  NEW = 'NEW',
  REJECTED = 'REJECTED',
  ACCEPTED = 'ACCEPTED',
}