export class FileUploadCompletedEvent {
  constructor(public readonly mediaId: string) {}
}
