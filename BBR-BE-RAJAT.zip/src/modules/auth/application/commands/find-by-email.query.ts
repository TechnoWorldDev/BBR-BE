export class FindByEmailQuery {
  constructor(public readonly email: string) {}
}
