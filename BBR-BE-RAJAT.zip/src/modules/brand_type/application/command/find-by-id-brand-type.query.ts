export class FindByIdBrandTypeQuery {
  constructor(public readonly id: string) {}
}
