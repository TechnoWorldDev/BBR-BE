export enum B2BFormSubmissionStatus {
  NEW = 'NEW',
  CONTACTED = 'CONTACTED',
  COMPLETED = 'COMPLETED',
}
