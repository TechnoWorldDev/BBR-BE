export class FileUploadErrorEvent {
  constructor(public readonly mediaId: string) {}
}
