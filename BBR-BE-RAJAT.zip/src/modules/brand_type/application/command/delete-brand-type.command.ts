export class DeleteBrandTypeCommand {
  constructor(public readonly id: string) {}
}
