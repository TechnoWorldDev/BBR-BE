export class RequestResetPasswordCommand {
  constructor(public readonly email: string) {}
}
