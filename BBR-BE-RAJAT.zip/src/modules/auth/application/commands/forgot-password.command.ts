export class ForgotPasswordCommand {
  constructor(public readonly email: string) {}
}
