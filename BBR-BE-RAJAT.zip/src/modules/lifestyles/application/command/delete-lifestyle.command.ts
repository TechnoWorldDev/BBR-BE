export class DeleteLifestyleCommand {
  constructor(public readonly id: string) {}
}
